# webshocket
a golang based webshell that uses websockets
